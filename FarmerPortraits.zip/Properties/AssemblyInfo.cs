using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyCompany("FarmerPortraits")]
[assembly: AssemblyConfiguration("Debug")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0+8a7f92897fb884a68c6d729b30eb3f18f1748b3b")]
[assembly: AssemblyProduct("FarmerPortraits")]
[assembly: AssemblyTitle("FarmerPortraits")]
[assembly: AssemblyVersion("1.0.0.0")]
